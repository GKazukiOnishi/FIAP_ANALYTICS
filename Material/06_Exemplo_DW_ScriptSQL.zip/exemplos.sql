mysql -u myUserName -p 'myUserName$dbDW' -h myUserName.mysql.pythonanywhere-services.com < construcaoDataMart.sql 
mysql -u myUserName -p 'myUserName$dbDW' -h myUserName.mysql.pythonanywhere-services.com < cargaDimensoes.sql
mysql -u myUserName -p 'myUserName$dbDW' -h myUserName.mysql.pythonanywhere-services.com < cargaFato.sql

SELECT L.ESTADO, L.CIDADE, L.REGIAO, T.TRIMESTRE, T.ANO, P.NOME, P.MODELO, P.GRUPO, FV.QUANTIDADE, FV.VALOR FROM FATOVENDA as FV INNER JOIN LOCALIZACAO as L ON L.ID = FV.IDLOCAL INNER JOIN PRODUTO as P on P.ID = FV.IDPRODUTO INNER JOIN TEMPO as T on T.ID = FV.IDTEMPO;

SELECT L.ESTADO, T.ANO, P.GRUPO, SUM(FV.QUANTIDADE), SUM(FV.VALOR) FROM FATOVENDA as FV INNER JOIN LOCALIZACAO as L ON L.ID = FV.IDLOCAL INNER JOIN PRODUTO as P on P.ID = FV.IDPRODUTO INNER JOIN TEMPO as T on T.ID = FV.IDTEMPO GROUP BY L.ESTADO, T.ANO, P.GRUPO;



